(2014-04-03) Zmiana wersji drivera: 2.08.23.14		Do�o�enie urz�dzenia N21
(2014-04-03) Change version of driver: 2.08.23.14	Insert new device type N21

(2013-09-17) Zmiana wersji drivera: 2.08.23.13		Zmiana nazwy urz�dzenia PD8 i PD8W
(2013-09-17) Change version of driver: 2.08.23.13	New name of PD8 and PD8W

(2013-07-05) Zmiana wersji drivera: 2.08.23.12		Do�o�enie urzadzenia typu N43
(2013-07-05) Change version of driver: 2.08.23.12	Insert new device type N43

(2013-05-08) Zmiana wersji drivera: 2.08.23.11		Do�o�enie urzadzenia typu PD8W/PD8
(2013-05-08) Change version of driver: 2.08.23.11	Insert new device type PD8W/PD8

(2013-02-26) Zmiana wersji drivera: 2.08.28.10		Windows 8 compliant
(2013-02-26) Change version of driver: 2.08.28.10	Zgodny z Windows 8

(2013-02-02) Zmiana wersji drivera: 2.08.23.09		Do�o�enie urzadzenia typu PD8W
(2013-02-02) Change version of driver: 2.08.23.09	Insert new device type PD8W


(2012-03-02) Zmiana wersji drivera: 2.08.23.08		Do�o�enie urzadzenia typu SM61
(2012-03-02) Change version of driver: 2.08.23.08	Insert new device type SM61

(2011-09-05) Zmiana wersji drivera: 2.08.02.07		Do�o�enie urzadzenia typu P41
(2011-09-05) Change version of driver: 2.08.02.07	Insert new device type P41


(2010-09-23) Zmiana wersji drivera: 2.08.02.06	
(2010-09-23) Change version of driver: 2.08.02.06

(2010-03-23) Zmiana wersji drivera: 2.06.00.05	
(2010-03-23) Change version of driver: 2.06.00.05


(2009-09-02) Zmiana wersji drivera: 2.04.16.04	
(2009-09-02) Change version of driver: 2.04.16.04


(2008-09-01) Zmiana nazwa urzadzen: PD10, PD12, PD14, PD22, SMC, P43. wersja: 2.04.06.03	
(2008-09-01) Change names of devices: PD10, PD12, PD14, PD22, SMC, P43. version: 2.04.06.03


(2008-06-26) Drivery do urz�dze� firmy LUMEL: PD10, PD12, PD14, PD22, SMC, P43. wersja: 2.04.06.02	
(2008-06-26) Drivers for Lumel devices: PD10, PD12, PD14, PD22, SMC, P43. version: 2.04.06.02


(2008-04-10) Drivery do urz�dze� firmy LUMEL: PD10, PD12, PD14, PD22, SMC. wersja: 2.04.06.00	
(2008-04-10) Drivers for Lumel devices: PD10, PD12, PD14, PD22, SMC. version:2.04.06.00	